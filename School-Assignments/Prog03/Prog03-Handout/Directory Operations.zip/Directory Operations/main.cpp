//
//  main.cpp
//  Directory Operations, C++ version
//
//  Created by Jean-Yves Hervé on 2017-02-15.
//	Edited 2018-03-30
//
//	Just for reference, this is a C++ version of the same code.
//	In this version, we only need one pass since C++ has dynamic
//	data types (here I use a vector).

#include <iostream>
#include <vector>
#include <sys/stat.h>
#include <dirent.h>

using namespace std;
int main(int argc, const char * argv[]) {

	const char* dataRootPath = argv[1];
	
    DIR* directory = opendir(dataRootPath);
    if (directory == NULL) {
		cout << "data folder " << dataRootPath << " not found" << endl;
		exit(1);
	}
	
    struct dirent* entry;
    vector<string>  fileName;
    while ((entry = readdir(directory)) != NULL) {
        const char* name = entry->d_name;
        if (name[0] != '.') {
			fileName.push_back(string(entry->d_name));
        }
    }
	closedir(directory);
	
	cout << fileName.size() << " files found" << endl;
	for (int k=0; k<fileName.size(); k++)
		cout << "\t" << fileName[k] << endl;

	return 0;
}
